<?php
class ConexionBD{
	public static function CadenaCN(){
		return array(
			"servidor" => "localhost",
			"usuario" => "root",
			"password" => "",
			"basedatos" => "egipcio_nuevo",
		);
	}
}
?>
